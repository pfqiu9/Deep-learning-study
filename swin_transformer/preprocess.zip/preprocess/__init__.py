from preprocess.timm_autoaugment import RawTimmAutoAugment
from preprocess.random_erasing import RandomErasing
from preprocess.operators import DecodeImage
from preprocess.operators import ResizeImage
from preprocess.operators import CropImage
from preprocess.operators import RandCropImage
from preprocess.operators import RandFlipImage
from preprocess.operators import NormalizeImage


import numpy as np
from PIL import Image


def transform(data, ops=[]):
    """ transform """
    for op in ops:
        data = op(data)
    return data



class TimmAutoAugment(RawTimmAutoAugment):
    """ TimmAutoAugment wrapper to auto fit different img tyeps. """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def __call__(self, img):
        if not isinstance(img, Image.Image):
            img = np.ascontiguousarray(img)
            img = Image.fromarray(img)

        img = super().__call__(img)

        if isinstance(img, Image.Image):
            img = np.asarray(img)

        return img
