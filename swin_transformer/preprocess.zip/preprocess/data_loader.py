from imagenet_dataset import *
from paddle.io import DistributedBatchSampler, BatchSampler, DataLoader
from preprocess.batch_operators import *

def build_train_dataloader(device, seed=None):
    # build dataset
    dataset = ImageNetDataset(
        image_root='/home/aistudio/work/data',
        cls_label_path='/home/aistudio/work/data/val_list.txt',
        transform_ops=[
            {'DecodeImage':{'to_rgb': True, 'channel_first':False}},
            {'RandCropImage':{'size':224, 'interpolation':'bicubic', 'backend':'pil'}},
            {'RandFlipImage':{'flip_code': 1}},
            {'TimmAutoAugment':{'config_str':'rand-m9-mstd0.5-inc1', 'interpolation':'bicubic', 'img_size':224}},
            {'NormalizeImage':{'scale':1.0/255.0, 'mean':[0.485, 0.456, 0.406], 'std':[0.229, 0.224, 0.225],'order':''}},
            {'RandomErasing':{'EPSILON':0.25, 'sl':0.02, 'sh':1.0/3.0, 'r1':0.3, 'attempt':10, 'use_log_aspect':True, 'mode':'pixel'}}
        ]
    )

    print("build dataset({}) success...".format(dataset))
    #logger.debug("build dataset({}) success...".format(dataset))

    # build sampler
    batch_sampler = DistributedBatchSampler(
        dataset=dataset,
        batch_size=128,
        drop_last=False,
        shuffle=True
    )

    print("build batch_sampler({}) success...".format(batch_sampler))
    #logger.debug("build batch_sampler({}) success...".format(batch_sampler))

    # build batch operator
    def mix_collate_fn(batch):
        batch = transform(batch, batch_ops)
        # batch each field
        slots = []
        for items in batch:
            for i, item in enumerate(items):
                if len(slots) < len(items):
                    slots.append([item])
                else:
                    slots[i].append(item)
        return [np.stack(slot, axis=0) for slot in slots]


    batch_ops = [OpSampler(MixupOperator={'alpha': 0.8, 'prob': 0.5}, CutmixOperator={'alpha': 1.0, 'prob': 0.5})]
    batch_collate_fn = mix_collate_fn


    # build dataloader
    num_workers = 0
    use_shared_memory = True
    data_loader = DataLoader(
        dataset=dataset,
        places=device,
        num_workers=num_workers,
        #return_list=True,
        use_shared_memory=use_shared_memory,
        batch_sampler=batch_sampler,
        collate_fn=batch_collate_fn)

    print("build data_loader({}) success...".format(data_loader))
    #logger.debug("build data_loader({}) success...".format(data_loader))
    return data_loader


def build_eval_dataloader(device, seed=None):
    # build dataset
    dataset = ImageNetDataset(
        image_root='/home/aistudio/work/data',
        cls_label_path='/home/aistudio/work/data/val_list.txt',
        transform_ops=[
            {'DecodeImage':{'to_rgb': True, 'channel_first':False}},
            {'ResizeImage':{'resize_short':256, 'interpolation':'bicubic', 'backend':'pil'}},
            {'CropImage':{'size': 224}},
            {'NormalizeImage':{'scale':1.0/255.0, 'mean':[0.485, 0.456, 0.406], 'std':[0.229, 0.224, 0.225],'order':''}},
        ]
    )

    print("build dataset({}) success...".format(dataset))
    #logger.debug("build dataset({}) success...".format(dataset))

    # build sampler
    batch_sampler = DistributedBatchSampler(
        dataset=dataset,
        batch_size=128,
        drop_last=False,
        shuffle=False
    )

    print("build batch_sampler({}) success...".format(batch_sampler))
    #logger.debug("build batch_sampler({}) success...".format(batch_sampler))

    # build batch operator
    batch_collate_fn = None

    # build dataloader
    num_workers = 0
    use_shared_memory = True
    data_loader = DataLoader(
        dataset=dataset,
        places=device,
        num_workers=num_workers,
        #return_list=True,
        use_shared_memory=use_shared_memory,
        batch_sampler=batch_sampler,
        collate_fn=batch_collate_fn)

    print("build data_loader({}) success...".format(data_loader))
    #logger.debug("build data_loader({}) success...".format(data_loader))
    return data_loader
    
